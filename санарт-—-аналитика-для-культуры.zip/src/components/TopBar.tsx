import React, { useState } from 'react';
import { 
  Building2, 
  CalendarRange, 
  ChevronDown, 
  Menu,
  Sparkles,
  CheckCircle2
} from 'lucide-react';
import { Institution, TimePeriodFilter, UserRole } from '../types';
import { INSTITUTIONS } from '../data/mockData';

interface TopBarProps {
  selectedInstitution: Institution;
  onSelectInstitution: (institution: Institution) => void;
  periodFilter: TimePeriodFilter;
  onPeriodFilterChange: (period: TimePeriodFilter) => void;
  userRole: UserRole;
  onUserRoleChange: (role: UserRole) => void;
  onOpenMobileSidebar: () => void;
  onOpenCreateEvent?: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  selectedInstitution,
  onSelectInstitution,
  periodFilter,
  onPeriodFilterChange,
  userRole,
  onUserRoleChange,
  onOpenMobileSidebar,
  onOpenCreateEvent,
}) => {
  const [isInstDropdownOpen, setIsInstDropdownOpen] = useState(false);
  const [isPeriodDropdownOpen, setIsPeriodDropdownOpen] = useState(false);
  const [isUserDropdownOpen, setIsUserDropdownOpen] = useState(false);

  const periods: { id: TimePeriodFilter; label: string }[] = [
    { id: 'custom', label: '8 августа — 9 сентября' },
    { id: 'today', label: 'Сегодня' },
    { id: 'yesterday', label: 'Вчера' },
    { id: 'week', label: 'Неделя' },
    { id: 'month', label: 'Месяц' },
    { id: 'quarter', label: 'Квартал' },
  ];

  return (
    <header className="h-[76px] px-4 sm:px-8 flex items-center justify-between gap-4 border-b border-[#e8e7e2]/50 bg-[#f5f5f2] sticky top-0 z-30">
      {/* Left: Mobile hamburger + Institution Chip */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobileSidebar}
          className="lg:hidden p-2 rounded-xl bg-white border border-[#e8e7e2] text-[#17171a] shadow-xs"
          aria-label="Открыть меню"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Institution Selector Chip */}
        <div className="relative">
          <button
            onClick={() => setIsInstDropdownOpen(!isInstDropdownOpen)}
            className="inline-flex items-center gap-2.5 bg-white border border-[#e8e7e2] rounded-full px-4 py-2.5 text-[14px] font-semibold text-[#17171a] shadow-[0_1px_2px_rgba(16,16,15,0.04),0_10px_24px_rgba(16,16,15,0.035)] hover:border-[#ff7a45] transition-all cursor-pointer"
          >
            {/* Museum classical icon from reference */}
            <svg viewBox="0 0 20 20" fill="none" className="w-4 h-4 text-[#8b8b92] shrink-0">
              <path d="M10 2 3 6v1.2h14V6L10 2Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
              <path d="M4 8.2v7.4M7 8.2v7.4M13 8.2v7.4M16 8.2v7.4" stroke="currentColor" strokeWidth="1.5" />
              <path d="M3 17h14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
            </svg>

            <span className="truncate max-w-[180px] sm:max-w-[280px]">
              {selectedInstitution.name}
            </span>

            <ChevronDown className="w-3.5 h-3.5 text-[#b7b7bc] shrink-0 ml-0.5" />

            {/* Amber warning dot if dataQuality has flag */}
            {selectedInstitution.dataQuality === 'divergence_detected' && (
              <span 
                className="w-2 h-2 rounded-full bg-[#e8a13c] ring-3 ring-[#fbecd4] shrink-0 ml-1" 
                title="Качество данных: обнаружены расхождения"
              />
            )}
          </button>

          {/* Institution Dropdown */}
          {isInstDropdownOpen && (
            <div className="absolute left-0 mt-2 w-80 sm:w-96 bg-white border border-[#e8e7e2] rounded-2xl shadow-xl z-50 max-h-96 overflow-y-auto divide-y divide-[#e8e7e2]/60 p-1">
              <div className="p-3 text-[11px] font-bold text-[#8b8b92] uppercase tracking-wider">
                Официальный реестр учреждений (19)
              </div>
              {INSTITUTIONS.map((inst) => (
                <button
                  key={inst.id}
                  onClick={() => {
                    onSelectInstitution(inst);
                    setIsInstDropdownOpen(false);
                  }}
                  className={`w-full text-left p-3 rounded-xl hover:bg-[#f5f5f2] flex items-center justify-between gap-2 transition-colors ${
                    inst.id === selectedInstitution.id ? 'bg-[#f5f5f2] font-semibold text-[#ff7a45]' : 'text-[#17171a]'
                  }`}
                >
                  <div className="min-w-0 flex-1">
                    <div className="text-[13px] font-semibold truncate">
                      {inst.name}
                    </div>
                    <div className="text-[11px] text-[#8b8b92]">
                      {inst.city} • {inst.type}
                    </div>
                  </div>
                  {inst.dataQuality === 'divergence_detected' ? (
                    <span className="w-2 h-2 rounded-full bg-[#e8a13c] ring-2 ring-[#fbecd4] shrink-0" title="Расхождение" />
                  ) : (
                    <span className="w-2 h-2 rounded-full bg-[#7fbf8a] shrink-0" />
                  )}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Right: Date Picker Chip + User Chip */}
      <div className="flex items-center gap-3">
        {/* Date Selector Chip */}
        <div className="relative hidden sm:block">
          <button
            onClick={() => setIsPeriodDropdownOpen(!isPeriodDropdownOpen)}
            className="inline-flex items-center gap-2.5 bg-white border border-[#e8e7e2] rounded-full px-4 py-2.5 text-[14px] font-semibold text-[#17171a] shadow-[0_1px_2px_rgba(16,16,15,0.04),0_10px_24px_rgba(16,16,15,0.035)] hover:border-[#ff7a45] transition-all cursor-pointer"
          >
            <CalendarRange className="w-4 h-4 text-[#8b8b92]" />
            <span>
              {periodFilter === 'custom' ? '8 августа — 9 сентября' : periods.find(p => p.id === periodFilter)?.label}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-[#b7b7bc]" />
          </button>

          {isPeriodDropdownOpen && (
            <div className="absolute right-0 mt-2 w-56 bg-white border border-[#e8e7e2] rounded-2xl shadow-xl z-50 p-1.5 space-y-1">
              {periods.map((p) => (
                <button
                  key={p.id}
                  onClick={() => {
                    onPeriodFilterChange(p.id);
                    setIsPeriodDropdownOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 text-xs font-semibold rounded-lg transition-colors ${
                    periodFilter === p.id ? 'bg-[#121214] text-white' : 'text-[#17171a] hover:bg-[#f5f5f2]'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* User Account Chip */}
        <div className="relative">
          <button
            onClick={() => setIsUserDropdownOpen(!isUserDropdownOpen)}
            className="inline-flex items-center gap-2 text-[14px] font-semibold text-[#17171a] hover:opacity-80 transition-opacity cursor-pointer select-none"
          >
            {/* Avatar circle with U */}
            <div className="w-8 h-8 rounded-full bg-[#121214] text-white flex items-center justify-center font-bold text-xs">
              U
            </div>
            <span className="hidden md:inline text-[13px] text-[#17171a] font-medium">
              user_login@mail.ru
            </span>
          </button>

          {isUserDropdownOpen && (
            <div className="absolute right-0 mt-2 w-64 bg-white border border-[#e8e7e2] rounded-2xl shadow-xl z-50 p-3 text-xs divide-y divide-[#e8e7e2]/60">
              <div className="pb-2">
                <div className="font-bold text-[#17171a]">user_login@mail.ru</div>
                <div className="text-[11px] text-[#8b8b92]">Директор по развитию / Аналитик</div>
              </div>
              <div className="py-2 space-y-1">
                <div className="text-[10px] font-bold text-[#b7b7bc] uppercase">Роль доступа</div>
                {(['organizer', 'admin', 'viewer'] as UserRole[]).map((r) => (
                  <button
                    key={r}
                    onClick={() => {
                      onUserRoleChange(r);
                      setIsUserDropdownOpen(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg flex items-center justify-between text-xs ${
                      userRole === r ? 'bg-[#ff7a45]/10 text-[#ff7a45] font-bold' : 'text-[#17171a] hover:bg-[#f5f5f2]'
                    }`}
                  >
                    <span>{r === 'organizer' ? 'Организатор' : r === 'admin' ? 'Руководитель' : 'Наблюдатель'}</span>
                    {userRole === r && <CheckCircle2 className="w-3.5 h-3.5 text-[#ff7a45]" />}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
